/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.cs218serealization;

/**
 *
 * @author Shamal Prasad
 */
public class Employee implements java.io.Serializable{
    public String name;
    public String address;
    public transient int SSN; //removes variable from serialization process
    public int number;

    public void mailCheck(){
        System.out.println("Mailing a check to " + name + " " + address);
    }
}
