/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.cs218serealization;

/**
 *
 * @author Shamal Prasad
 */

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;

public class SerializationDemo {

    public static void main(String[] args) {

    Employee e = new Employee();
    e.name = "Ron kendale Dean";
    e.address = "Lautoka";
    e.SSN = 111222333;
    e.number = 100;

    try {
        FileOutputStream outFile = new FileOutputStream("employee.ser");
        ObjectOutputStream out = new ObjectOutputStream(outFile);
        out.writeObject(e);
        out.close();
        outFile.close();
        System.out.println("Serialized data is saved in main project file");


    } catch (IOException i){
        i.printStackTrace();
    }



    }
}
